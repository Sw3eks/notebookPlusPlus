# Android Notebook++ Application

This is an Android App call Notebook++, developed for the course Mobile Computing.

## Installation
Clone this repository and import into **Android Studio**
```bash
git clone https://gitlab.com/fabiansaacke/notebookplusplus.git
```
## Maintainers
This project is mantained by:
* [Fabian Saacke](https://gitlab.com/fabiansaacke)
